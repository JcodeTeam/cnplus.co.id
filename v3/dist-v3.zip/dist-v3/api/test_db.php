<?php
require_once './db.php';
echo "Berhasil terhubung ke database!";
